using UnityEngine;

public class StateWalk : State
{
    public StateWalk( StateMachineV3 _machine ) : base( _machine ) { }

    public override void OnEnter()
    {
    }

    public override void OnExit()
    {
    }

    public override void OnFixedUpdate()
    {
    }

    public override void OnTriggerEnter()
    {
    }

    public override void OnUpdate()
    {
    }
}
